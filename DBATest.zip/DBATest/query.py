import sqlite3


def check_avail(check_in, checkout, room_type, hotel):
    connection = sqlite3.connect("thehotel.db")
    cursor = connection.cursor()
    cursor.execute("SELECT COUNT(*) FROM Rooms WHERE Room_type = " + room_type + " AND Hotel_no = " + hotel + ""
                   " AND id NOT IN"
                   " (SELECT DISTINCT Room_id FROM Reservation "
                   "WHERE check_in <= " + check_in + " AND checkout >= " + checkout + ")"
                   + checkout + "")
    count = cursor.fetchall()
    connection.commit()
    connection.close()
    return count


def check_avail_all(check_in, checkout, room_type):
    connection = sqlite3.connect("thehotel.db")
    cursor = connection.cursor()
    cursor.execute("SELECT COUNT(*) FROM Rooms WHERE Room_type = " + room_type + " AND id NOT IN"
                   " (SELECT DISTINCT Room_id FROM Reservation "
                   "WHERE check_in <= " + check_in + " AND checkout >= " + checkout + ")")
    count = cursor.fetchall();
    connection.commit()
    connection.close()
    return count


def retrieve_first(check_in, checkout, room_type, hotel, ):
    connection = sqlite3.connect("thehotel.db")
    cursor = connection.cursor()
    cursor.execute("SELECT FROM Rooms WHERE Room_type = " + room_type + " AND Hotel_no = " + hotel + ""
                   " AND id NOT IN"
                   " (SELECT DISTINCT Room_id FROM Reservation "
                   "WHERE check_in <= " + check_in + " AND checkout >= " + checkout + " ORDER BY ROWID ASC LIMIT 1")



