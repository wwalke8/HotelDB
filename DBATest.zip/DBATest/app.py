import sqlite3
import query
from flask import Flask, redirect, render_template, request, url_for, session

app = Flask(__name__)
app.secret_key = "hello"


@app.route('/', methods=['GET', 'POST'])
def index():
    #connection = sqlite3.connect("project_hotel.db")
    #cursor = connection.cursor()
    #query_list = [(1, "Towson", "Maryland", 4102528808),
                  #(2, "Towson", "Maryland", 4103395984),
                 # (3, "Baltimore", "Maryland", 4102050294),
                 # (4, "Catonsville", "Maryland", 4107198588)]

    #connection.executemany("INSERT INTO Hotels VALUES (?, ?, ?, ?)", query_list)
    #connection.commit()
    #cursor.execute("SELECT * FROM Hotels")
    #result = cursor.fetchall()
    #session["result"] = result
    #connection.close()
    if request.method == 'POST':
        if "guest" in request.form:
            return redirect(url_for("guest"))
        elif "employee" in request.form:
            return redirect(url_for("employee_sign_in"))
    return render_template("Enter.html")


# GENERAL PAGES

@app.route('/location', methods=['GET', 'POST'])
def location():
    if request.method == 'POST':
        loc = request.form["location"]
        session["loc"] = loc
        if "user" in session:
            return redirect("front_desk_options")
        return redirect(url_for("add_reservation"))
    return render_template("location.html")


@app.route('/addReservation', methods=['GET', 'POST'])
def add_reservation():
    if request.method == 'POST':
        check_in = request.form["check_in"]
        check_out = request.form["check_out"]
        session["check_in"] = check_in
        session["check_out"] = check_out
        if query.check_avail(session["check_in"], session["check_out"]) == 0:
            return 'please choose new date'
        else:
            pass
    return render_template("reservation.html", user=session["loc"])


#  PAGES FOR EMPLOYEES
@app.route('/employeeSignIn', methods=['GET', 'POST'])
def employee_sign_in():
    if request.method == 'POST':
        emp_id = request.form["employee_id"]
        session["emp_id"] = emp_id
        # QUERY CHECK session["emp_id"] return privilege
        # result = fetchall
        # if none
        # - return render_template("employeeSignIn.html")
        # elif
        # - session ["privilege"] = "privilege"
        # - if session ["privilege"] = front-desk
        # - - return redirect(url_for("front_desk_options"))
        # - elif session ["privilege"] = "manager"
        # - - redirect(url_for("manager_options"))
        # - elif session["privilege"] = "corp"
        # - -  redirect(url_for("location"))
        return redirect(url_for("front_desk_options"))
    return render_template("employeeSignIn.html")


@app.route('/frontDeskOptions', methods=['GET', 'POST'])
def front_desk_options():
    if request.method == 'POST':
        if "new_reservation" in request.form:
            return redirect(url_for("add_reservation"))
        elif "check_reservation" in request.form:
            return 'check reservation'
        elif "delete_reservation" in request.form:
            return 'delete reservation'
        elif "check_availability" in request.form:
            return 'check availability'
    return render_template("frontdeskOptions.html")


@app.route('/managerOptions', methods=['GET', 'POST'])
def manager_options():
    if request.method == 'POST':
        if "new_employee" in request.form:
            return 'new employee'
        elif "fire_employee" in request.form:
            return 'fire employee'
        elif "front_desk" in request.form:
            return 'front desk'
    return render_template("managerOptions.html")


# PAGES FOR GUESTS


@app.route('/guest', methods=['GET', 'POST'])
def guest():
    if request.method == 'POST':
        if "new" in request.form:
            return redirect(url_for("location"))
        elif "member" in request.form:
            return redirect(url_for("guest_sign_in"))
    return render_template("guestEntry.html", result=session["result"])


@app.route('/guestSignIn', methods=['GET', 'POST'])
def guest_sign_in():
    if request.method == 'POST':
        return redirect(url_for("guest_options"))
    return render_template("guestSignIn.html")


@app.route('/guestOptions', methods=['GET', 'POST'])
def guest_options():
    if request.method == 'POST':
        if "check_reservation" in request.form:
            return 'check reservation'
        elif "delete_reservation" in request.form:
            return 'delete reservation'
        elif "view_bill" in request.form:
            return 'view bill'
    return render_template("guestOptions.html")


if __name__ == '__main__':
    app.run(debug=True)
